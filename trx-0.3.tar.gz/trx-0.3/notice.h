#ifndef NOTICE_H
#define NOTICE_H

#define COPYRIGHT "trx (C) Copyright 2014 Mark Hills <mark@xwax.org>"

#endif
